require('dotenv').config();
require('./server');
require('./db_connection');
